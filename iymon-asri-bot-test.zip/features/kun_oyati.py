# === features/kun_oyati.py ===
import requests
import random
from telegram import Update
from telegram.ext import ContextTypes

def get_daily_ayah():
    random_ayah = random.randint(1, 6236)
    url = f"https://api.alquran.cloud/v1/ayah/{random_ayah}"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()["data"]
            return {
                "surah": data["surah"]["englishName"],
                "number": data["numberInSurah"],
                "text": data["text"]
            }
        else:
            print("API xatolik:", response.status_code)
            return None
    except Exception as e:
        print("Xatolik oyat olishda:", e)
        return None

async def kun_oyati(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ayah = get_daily_ayah()
    if not ayah:
        await update.callback_query.answer("❌ Oyatni olishda xatolik yuz berdi.")
        return

    text = (
        f"📖 <b>{ayah['surah']} – {ayah['number']}-oyat</b>\n\n"
        f"🕋 <i>{ayah['text']}</i>"
    )

    chat_id = update.callback_query.message.chat.id
    await context.bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML")
    await update.callback_query.answer()

