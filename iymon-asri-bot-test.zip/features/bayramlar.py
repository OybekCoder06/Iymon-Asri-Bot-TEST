# === features/bayramlar.py ===
import json
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from core.localization import get_lang, texts

# Bayramlar ma'lumotlarini yuklash
def load_bayramlar():
    with open("data/bayramlar.json", "r", encoding="utf-8") as f:
        return json.load(f)

# Qancha kun qolganini hisoblash
def days_left(miladi_str):
    today = datetime.now().date()
    bayram_date = datetime.strptime(miladi_str, "%Y-%m-%d").date()
    delta = (bayram_date - today).days
    return delta

# Bayramlar menyusini ko‘rsatish
def bayram_buttons(lang):
    bayramlar = load_bayramlar()
    buttons = [
        [InlineKeyboardButton(b["name"], callback_data=f"bayram_{b['id']}")] for b in bayramlar
    ]
    buttons.append([InlineKeyboardButton("🔙 " + texts[lang]["back"], callback_data="back_to_menu")])
    return InlineKeyboardMarkup(buttons)

# Bayramlar tugmasi bosilganda
async def show_bayram_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lang = get_lang(update.effective_user.id)
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=texts[lang]["choose_bayram"],
        reply_markup=bayram_buttons(lang)
    )

# Har bir bayram tugmasi bosilganda
async def show_bayram_info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    lang = get_lang(query.from_user.id)
    bayram_id = query.data.replace("bayram_", "")
    bayramlar = load_bayramlar()

    text = "Bayram topilmadi."
    for b in bayramlar:
        if b["id"] == bayram_id:
            qolgan = days_left(b["miladi"])
            text = (
                f"🎉 <b>{b['name']}</b>\n\n"
                f"📅 <b>Sana:</b> {b['miladi']}\n"
                f"📖 <b>Ma’lumot:</b> {b['info']}\n"
                f"⏳ <b>{qolgan} kun qoldi</b>\n\n"
                f"🕌 <i>{b['tabrik']}</i>"
            )
            break

    await query.edit_message_text(text, parse_mode="HTML", reply_markup=bayram_buttons(lang))
