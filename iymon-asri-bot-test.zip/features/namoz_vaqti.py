# === features/namoz_vaqti.py ===
import requests
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup
from telegram.ext import ContextTypes
from core.storage import get_lang, update_user
from core.localization import texts
from telegram import ReplyKeyboardRemove
from features.ob_havo import show_weather_by_location
from features.ob_havo import show_weather_by_location  # Yangi funksiya
from telegram import ReplyKeyboardRemove

async def handle_namoz_vaqti(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lang = get_lang(update.effective_user.id)

    keyboard = [
        [InlineKeyboardButton("📅 Bugungi vaqtlar", callback_data="today_prayers")],
        [InlineKeyboardButton("📆 Haftalik vaqtlar", callback_data="weekly_prayers")]
    ]

    # Foydalanuvchidan joylashuv so‘raymiz
    location_keyboard = ReplyKeyboardMarkup(
        [[KeyboardButton("📍 Joylashuvni yuborish", request_location=True)]],
        resize_keyboard=True, one_time_keyboard=True
    )

    await update.callback_query.edit_message_text(
        text="📍 Joylashuvingizni yuboring:", reply_markup=None
    )

    await update.effective_chat.send_message(
        "📍 Iltimos, joylashuvingizni yuboring:",
        reply_markup=location_keyboard
    )

# Lokatsiyani qabul qilish va API orqali namoz vaqtlarini olish
async def handle_location(update: Update, context: ContextTypes.DEFAULT_TYPE):
    location = update.message.location
    user_id = update.effective_user.id

    if not location:
        await update.message.reply_text("❗ Joylashuv olinmadi.")
        return

    lat, lon = location.latitude, location.longitude

    # 1️⃣ Ob-havo uchun lokatsiya bo‘lsa:
    if context.user_data.get("waiting_for_weather"):
        context.user_data.pop("waiting_for_weather")
        await show_weather_by_location(update, context, lat, lon)
        return

    # 2️⃣ Namoz uchun default holatda:
    update_user(user_id, "lat", lat)
    update_user(user_id, "lon", lon)

    await update.message.reply_text(
        "✅ Joylashuv qabul qilindi. Namoz vaqtlari aniqlanmoqda...",
        reply_markup=ReplyKeyboardRemove()
    )

    await show_prayer_times(update, context, lat, lon)

async def show_prayer_times(update: Update, context: ContextTypes.DEFAULT_TYPE, lat, lon):
    url = "https://api.aladhan.com/v1/timings"
    params = {
        "latitude": lat,
        "longitude": lon,
        "method": 2,
    }
    try:
        res = requests.get(url, params=params)
        data = res.json()["data"]["timings"]
    except:
        await update.message.reply_text("❌ Namoz vaqtlarini olishda xatolik.")
        return

    msg = (
        f"🕌 <b>Bugungi namoz vaqtlaringiz:</b>\n\n"
        f"Bomdod: {data['Fajr']}\n"
        f"Quyosh: {data['Sunrise']}\n"
        f"Peshin: {data['Dhuhr']}\n"
        f"Asr: {data['Asr']}\n"
        f"Shom: {data['Maghrib']}\n"
        f"Xufton: {data['Isha']}"
    )

    await update.message.reply_text(msg, parse_mode="HTML")
