# === features/roza.py ===
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputFile
from telegram.ext import ContextTypes
from datetime import date, datetime
import json

# Ro‘za boshlanish sanasi (misol uchun 2025-yil Ramazon)
RAMAZON_BOSHLANISH = date(2025, 3, 1)
RAMAZON_TUGASH = date(2025, 3, 30)

# Ro‘za taqvimi (istalgan formatda yuklash mumkin — bu oddiy ko‘rinishda)
ROZA_TAQVIMI = [
    {"kun": 1, "sana": "2025-03-01", "saxarlik": "05:02", "iftorlik": "18:29"},
    {"kun": 2, "sana": "2025-03-02", "saxarlik": "05:00", "iftorlik": "18:30"},
    # ... 30 kunlik ro‘yxatni to‘ldiring
]

# Duolar
SAXARLIK_DUOSI = "<i>“Nawaitu an asuma ghadal li-llahi ta‘ala.”</i>\n<b>Ma’nosi:</b> Alloh roziligi uchun ertangi ro‘zani tutishga niyat qildim."
IFTOR_DUOSI = "<i>“Allohumma laka sumtu va bika amantu va ‘alayka tavakkaltu va ‘ala rizqika aftartu.”</i>\n<b>Ma’nosi:</b> Ey Alloh! Sen uchun ro‘za tutdim, Senga ishondim, Senga tavakkal qildim va Sening rizqing bilan iftor qildim."

async def handle_roza(update: Update, context: ContextTypes.DEFAULT_TYPE):
    today = date.today()
    msg = "🕓 <b>Ro‘za taqvimi</b>\n"

    if today < RAMAZON_BOSHLANISH:
        days_left = (RAMAZON_BOSHLANISH - today).days
        msg += f"📅 Ramazon {RAMAZON_BOSHLANISH.strftime('%Y-%m-%d')} kuni boshlanadi.\n⏳ Qolgan: {days_left} kun."
    elif today > RAMAZON_TUGASH:
        msg += "✅ Ramazon oyi tugagan."
    else:
        for item in ROZA_TAQVIMI:
            if item["sana"] == today.strftime("%Y-%m-%d"):
                msg += (
                    f"📆 Bugun {item['kun']}-kun ro‘za\n"
                    f"🌅 Saxarlik: {item['saxarlik']}\n"
                    f"🌇 Iftorlik: {item['iftorlik']}\n\n"
                    f"🤲 <b>Saxarlik duosi:</b>\n{SAXARLIK_DUOSI}\n\n"
                    f"🤲 <b>Iftorlik duosi:</b>\n{IFTOR_DUOSI}"
                )
                break
        else:
            msg += "📌 Bugungi kun uchun ma’lumot topilmadi."

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬅️ Ortga", callback_data="back_to_menu"), InlineKeyboardButton("🏠 Bosh menyu", callback_data="main_menu")]
    ])

    await update.callback_query.edit_message_text(msg, parse_mode="HTML", reply_markup=keyboard)
