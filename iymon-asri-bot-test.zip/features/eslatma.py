# === features/eslatma.py ===
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes
from core.storage import update_user, get_user
from core.scheduler import schedule_reminders

NAMOZLAR = ["Bomdod", "Peshin", "Asr", "Shom", "Xufton"]

# === Tugmalarni yasash ===
def build_reminder_keyboard(user_id):
    user_data = get_user(user_id)
    selected = user_data.get("reminders", [])
    offset = user_data.get("reminder_offset", 0)

    buttons = []
    row = []
    for i, nomoz in enumerate(NAMOZLAR):
        emoji = "✅" if nomoz in selected else "❌"
        row.append(InlineKeyboardButton(f"{emoji} {nomoz}", callback_data=f"toggle_{nomoz}"))
        if len(row) == 2 or i == len(NAMOZLAR)-1:
            buttons.append(row)
            row = []

    # 🔘 Eslatma vaqti tanlash
    offset_buttons = []
    for val, label in [(0, "🔔 Namoz vaqtida"), (15, "⏰ 15 daqiqa oldin"), (30, "⏰ 30 daqiqa oldin")]:
        text = f"✅ {label}" if offset == val else label
        offset_buttons.append(InlineKeyboardButton(text, callback_data=f"offset_{val}"))

    buttons.append(offset_buttons[:2])  # ikki ustun
    buttons.append([offset_buttons[2]])

    # Saqlash va ortga tugmalari
    buttons.append([
        InlineKeyboardButton("💾 Saqlash", callback_data="save_reminders"),
        InlineKeyboardButton("🔙 Ortga", callback_data="back_to_menu")
    ])

    return InlineKeyboardMarkup(buttons)

# === /eslatma komandasi ===
async def eslatma_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = str(update.effective_user.id)
    keyboard = build_reminder_keyboard(user_id)
    await update.callback_query.edit_message_text(
        "📌 Qaysi namozlarga eslatma olishni xohlaysiz?", reply_markup=keyboard
    )

# === Callback tugmalar ===
async def eslatma_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = str(query.from_user.id)
    user_data = get_user(user_id)
    if "reminders" not in user_data:
        user_data["reminders"] = []

    if query.data.startswith("toggle_"):
        namoz = query.data.split("_")[1]
        if namoz in user_data["reminders"]:
            user_data["reminders"].remove(namoz)
        else:
            user_data["reminders"].append(namoz)
        update_user(user_id, "reminders", user_data["reminders"])
        await query.edit_message_reply_markup(build_reminder_keyboard(user_id))

    elif query.data == "save_reminders":
        await query.edit_message_text("⏳ Eslatmalar saqlanmoqda...")
        await schedule_reminders(context.application, user_id)
        selected = get_user(user_id).get("reminders", [])
        if selected:
            msg = "✅ Quyidagi eslatmalar saqlandi:\n\n" + "\n".join([f"🕌 {n}" for n in selected])
        else:
            msg = "🚫 Hech qanday eslatma tanlanmadi."
        await context.bot.send_message(chat_id=query.message.chat_id, text=msg)

    elif query.data == "back_to_menu":
        from features.start import start
        await start(update, context)

    elif query.data.startswith("offset_"):
        new_offset = int(query.data.split("_")[1])
        current_offset = user_data.get("reminder_offset", 0)
        selected_reminders = user_data.get("reminders", [])

        if not selected_reminders:
            await query.answer("❗ Iltimos, avval kamida bitta namozni tanlang.", show_alert=True)
            return

        if new_offset == current_offset:
            await query.answer("✅ Vaqt allaqachon tanlangan.")
            return

        update_user(user_id, "reminder_offset", new_offset)
        await query.answer("✅ Vaqt saqlandi.")  # ❗ Alert
        await query.edit_message_reply_markup(build_reminder_keyboard(user_id))
