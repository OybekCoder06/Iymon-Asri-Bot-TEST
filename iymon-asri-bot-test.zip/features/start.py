from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from core.storage import get_lang
from core.localization import texts

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    lang = get_lang(user_id)

    keyboard = [
        [InlineKeyboardButton(texts[lang]["menu"][0], callback_data="namoz_vaqti"),
         InlineKeyboardButton(texts[lang]["menu"][1], callback_data="ob_havo")],
        [InlineKeyboardButton(texts[lang]["menu"][2], callback_data="bayramlar"),
         InlineKeyboardButton(texts[lang]["menu"][3], callback_data="hadis_oyat")],
        [InlineKeyboardButton(texts[lang]["menu"][4], callback_data="kun_oyati"),
         InlineKeyboardButton(texts[lang]["menu"][5], callback_data="eslatma")],
        [InlineKeyboardButton(texts[lang]["menu"][6], callback_data="til"),
         InlineKeyboardButton(texts[lang]["menu"][7], callback_data="roza")],
        [InlineKeyboardButton(texts[lang]["menu"][8], callback_data="help")]
    ]

    text = texts[lang]["start"] + "\n\n" + texts[lang]["choose_option"]

    if update.message:
        await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
    elif update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
