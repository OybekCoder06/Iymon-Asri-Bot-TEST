# === features/ob_havo.py ===
import requests
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

# API kalit va endpoint (misol uchun OpenWeatherMap)
API_KEY = "45dfc431aa9b4205b1eb067b34505bce"
ENDPOINT = "https://api.openweathermap.org/data/2.5/weather"

# Ob-havoni olish
async def get_weather(lat, lon):
    params = {
        "lat": lat,
        "lon": lon,
        "appid": API_KEY,
        "units": "metric",
        "lang": "uz"
    }
    try:
        res = requests.get(ENDPOINT, params=params)
        data = res.json()
        return data
    except Exception as e:
        print("❌ Ob-havo xatosi:", e)
        return None

# Foydalanuvchidan joylashuv so'rash
async def ask_location_for_weather(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [[
        InlineKeyboardButton("📍 Joylashuvni yuborish", callback_data="get_weather")
    ]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    context.user_data['waiting_for_weather'] = True
    await update.callback_query.edit_message_text(
        "📍 Ob-havo ma’lumotini olish uchun joylashuvingizni yuboring:",
        reply_markup=reply_markup
    )

# Ob-havo ma’lumotini chiqarish
async def show_weather(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = str(query.from_user.id)
    user_data = context.bot_data.get("user_data", {}).get(user_id, {})

    lat = user_data.get("lat")
    lon = user_data.get("lon")

    if not lat or not lon:
        await query.edit_message_text("❗ Joylashuv topilmadi. Iltimos, /location buyrug‘idan foydalaning.")
        return

    data = await get_weather(lat, lon)
    if not data or data.get("cod") != 200:
        await query.edit_message_text("❌ Ob-havo ma’lumotini olishda xatolik yuz berdi.")
        return

    weather = data["weather"][0]["description"].capitalize()
    temp = data["main"]["temp"]
    feels = data["main"]["feels_like"]
    city = data["name"]

    msg = (
        f"🌤 <b>{city}</b> shahri uchun ob-havo:\n"
        f"🌡 Harorat: {temp}°C (his qilinadi: {feels}°C)\n"
        f"☁️ Holat: {weather}"
    )

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬅️ Ortga", callback_data="back_to_menu")]
    ])

    await query.edit_message_text(msg, parse_mode="HTML", reply_markup=keyboard)

async def show_weather_by_location(update: Update, context: ContextTypes.DEFAULT_TYPE, lat, lon):
    data = await get_weather(lat, lon)
    if not data or data.get("cod") != 200:
        await update.message.reply_text("❌ Ob-havo ma’lumotini olishda xatolik yuz berdi.")
        return

    weather = data["weather"][0]["description"].capitalize()
    temp = data["main"]["temp"]
    feels = data["main"]["feels_like"]
    city = data["name"]

    msg = (
        f"🌤 <b>{city}</b> shahri uchun ob-havo:\n"
        f"🌡 Harorat: {temp}°C (his qilinadi: {feels}°C)\n"
        f"☁️ Holat: {weather}"
    )

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬅️ Ortga", callback_data="back_to_menu")]
    ])
    await update.message.reply_text(msg, parse_mode="HTML", reply_markup=keyboard)
