# === features/til.py ===
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from core.storage import update_user, get_lang
from core.localization import texts

langs = {
    "uz": "🇺🇿 O'zbekcha",
    "ru": "🇷🇺 Русский"
    
}

async def handle_til(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lang = get_lang(update.effective_user.id)

    buttons = [ 
        [InlineKeyboardButton(label, callback_data=f"lang_{code}")]
        for code, label in langs.items()
    ]
    keyboard = InlineKeyboardMarkup(buttons)

    await update.callback_query.edit_message_text(
        texts[lang]["choose_lang"], reply_markup=keyboard
    )

async def set_lang(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id

    lang_code = query.data.replace("lang_", "")
    update_user(user_id, "lang", lang_code)
    
    await query.answer("✅ Til yangilandi")

    
    await query.edit_message_text(
        texts[lang_code]["start"] + "\n\n" + texts[lang_code]["choose_option"],
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton(texts[lang_code]["menu"][0], callback_data="namoz_vaqti"),
             InlineKeyboardButton(texts[lang_code]["menu"][1], callback_data="ob_havo")],
            [InlineKeyboardButton(texts[lang_code]["menu"][2], callback_data="bayramlar"),
             InlineKeyboardButton(texts[lang_code]["menu"][3], callback_data="hadis_oyat")],
            [InlineKeyboardButton(texts[lang_code]["menu"][4], callback_data="kun_oyati"),
             InlineKeyboardButton(texts[lang_code]["menu"][5], callback_data="eslatma")],
            [InlineKeyboardButton(texts[lang_code]["menu"][6], callback_data="til"),
             InlineKeyboardButton(texts[lang_code]["menu"][7], callback_data="roza")],
            [InlineKeyboardButton(texts[lang_code]["menu"][8], callback_data="help")],
        ])
    )

