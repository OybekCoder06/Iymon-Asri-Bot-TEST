# === features/hadis_oyat.py ===
import random
import json
import requests
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from core.localization import get_lang, texts

# === Hadislar faylini o‘qish ===
def load_hadislar():
    with open("data/hadislar.json", "r", encoding="utf-8") as f:
        return json.load(f)

# === Oyatni API orqali olish ===
def get_random_ayah():
    random_ayah = random.randint(1, 6236)
    url = f"https://api.alquran.cloud/v1/ayah/{random_ayah}"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()["data"]
            return {
                "surah": data["surah"]["englishName"],
                "number_in_surah": data["numberInSurah"],
                "text": data["text"]
            }
    except:
        return None

# === /hadis_oyat yoki menyudan kirganda ===
async def hadis_oyat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lang = get_lang(update.effective_user.id)
    keyboard = [
        [InlineKeyboardButton("📜 " + texts[lang]["hadis_oyat_hadis"], callback_data="show_hadis")],
        [InlineKeyboardButton("📖 " + texts[lang]["hadis_oyat_oyat"], callback_data="show_oyat")],
        [InlineKeyboardButton("🔙 " + texts[lang]["back"], callback_data="back_to_menu")],
    ]
    await update.callback_query.edit_message_text(
        texts[lang]["hadis_oyat_intro"],
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# === Callback ===
async def hadis_oyat_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id
    lang = get_lang(user_id)

    if query.data == "show_hadis":
        hadislar = load_hadislar()
        hadis = random.choice(hadislar)
        await query.message.reply_text("📜 " + hadis)

    elif query.data == "show_oyat":
        oyat = get_random_ayah()
        if oyat:
            msg = f"📖 <b>{oyat['surah']} – {oyat['number_in_surah']}-oyat</b>\n\n🕋 <i>{oyat['text']}</i>"
            await query.message.reply_text(msg, parse_mode="HTML")
        else:
            await query.answer("❗ Oyatni olishda xatolik yuz berdi", show_alert=True)

    elif query.data == "back_to_menu":
        from features.start import start
        await start(update, context)
    print("📌 hadis_oyat_callback ishga tushdi")
