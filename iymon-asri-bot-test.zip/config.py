# === config.py ===
BOT_TOKEN = "7643354807:AAGUqyvAjazsvCNrBPs0223pvxsnPDLbUGU"  # Bu yerga o'zingizning Telegram bot tokeningizni qo'ying
DEFAULT_LANG = "uz"

