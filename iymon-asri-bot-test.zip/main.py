import asyncio
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    CallbackQueryHandler,
)
from config import BOT_TOKEN
from features.start import start
from core.storage import load_user_data
from features.namoz_vaqti import handle_namoz_vaqti, handle_location
from telegram.ext import MessageHandler, filters
from features.til import handle_til, set_lang
from features.kun_oyati import kun_oyati
from core.scheduler import start_scheduler
from features.roza import handle_roza
from features.ob_havo import ask_location_for_weather, show_weather
from telegram.ext import CallbackQueryHandler
from features.start import start 
from features.eslatma import eslatma_command, eslatma_callback
from features.hadis_oyat import hadis_oyat, hadis_oyat_callback


async def on_startup(app):
    await start_scheduler(app)
    print("🟢 Bot ishga tushdi.")

def main():
    app = ApplicationBuilder().token(BOT_TOKEN).post_init(on_startup).build()

    # /start komandasi
    app.add_handler(CommandHandler("start", start))

    # /hadis_oyat yoki menyudan kirganda (menu_router dan emas)
    app.add_handler(CallbackQueryHandler(hadis_oyat, pattern="^hadis_oyat$"))

    # ichki tugmalar: show_hadis, show_oyat, back_to_menu
    app.add_handler(CallbackQueryHandler(hadis_oyat_callback, pattern="^(show_hadis|show_oyat|back_to_menu)$"))


    #handle_eslatma uchun
    app.add_handler(CallbackQueryHandler(eslatma_command, pattern="^eslatma$"))
    app.add_handler(CallbackQueryHandler(
        eslatma_callback,
        pattern=r"^(toggle_|offset_).*|^save_reminders$|^back_to_menu$"
    ))

    #namoz_vaqti uchun joylashuvni qabul qilish
    app.add_handler(MessageHandler(filters.LOCATION, handle_location))


    # Bosh menyu tugmalari uchun callback handler
    app.add_handler(CallbackQueryHandler(menu_router)) 

    print("⏳ Ishga tushirilmoqda...")
    app.run_polling()

# 👇 Callback tugmalar yo‘naltiruvchisi (hozircha log chiqaradi)
async def menu_router(update, context):
    query = update.callback_query
    await query.answer()
    print("Callback tugma:", query.data)

    data = query.data

    if data == "show_hadis" or data == "show_oyat" or data == "back_to_menu":
        from features.hadis_oyat import hadis_oyat_callback
        await hadis_oyat_callback(update, context)

    elif data == "namoz_vaqti":
        await handle_namoz_vaqti(update, context)

    elif data == "ob_havo":
        await ask_location_for_weather(update, context)

    elif data == "get_weather":
        await show_weather(update, context)

    elif data == "til":
        await handle_til(update, context)

    elif data == "kun_oyati":
        await kun_oyati(update, context)

    elif data == "roza":
        await handle_roza(update, context)

    elif data == "back_to_menu" or data == "main_menu":
        await start(update, context)

    elif data == "eslatma":
        await eslatma_command(update, context)

    elif data.startswith("lang_"):
        await set_lang(update, context)

    elif data == "bayramlar":
        from features.bayramlar import show_bayram_menu
        await show_bayram_menu(update, context)
    elif data.startswith("bayram_"):
        from features.bayramlar import show_bayram_info
        await show_bayram_info(update, context)


    else:
        await query.edit_message_text(f"🔧 {data} xizmati ishlab chiqilmoqda.")

if __name__ == "__main__":
    asyncio.run(main())
