# === core/scheduler.py ===
import asyncio
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from datetime import datetime, timedelta
from core.storage import get_user
from features.namoz_vaqti import show_prayer_times

scheduler = AsyncIOScheduler()

# === Eslatma yuborish funksiyasi ===
async def send_reminder(bot, chat_id, prayer_name):
    message = f"🕌 {prayer_name} namozining vaqti keldi. Namozni o‘z vaqtida o‘qishga harakat qiling."
    await bot.send_message(chat_id=chat_id, text=message)

# === Har bir namoz uchun jadval tuzish ===
def schedule_prayer(app, user_id, chat_id, prayer_name, prayer_time_str, offset_minutes):
    now = datetime.now()
    try:
        prayer_time = datetime.strptime(prayer_time_str, "%H:%M")
    except ValueError:
        return

    trigger_time = now.replace(hour=prayer_time.hour, minute=prayer_time.minute, second=0, microsecond=0) - timedelta(minutes=offset_minutes)
    if trigger_time < now:
        trigger_time += timedelta(days=1)

    job_id = f"{user_id}_{prayer_name}"
    scheduler.add_job(
        send_reminder,
        trigger="date",
        run_date=trigger_time,
        args=[app.bot, chat_id, prayer_name],
        id=job_id,
        replace_existing=True
    )

# === Jadvalni tozalab qayta yuklash ===
async def schedule_reminders(app, user_id):
    user_data = get_user(user_id)
    reminders = user_data.get("reminders", [])
    offset = user_data.get("reminder_offset", 0)
    location = user_data.get("location")
    chat_id = int(user_id)

    if not location:
        return

    lat, lon = location["lat"], location["lon"]
    prayers = show_prayer_times(lat, lon)
    if not prayers:
        return

    for prayer_name in reminders:
        time_key = {
            "Bomdod": "Fajr",
            "Peshin": "Dhuhr",
            "Asr": "Asr",
            "Shom": "Maghrib",
            "Xufton": "Isha",
        }.get(prayer_name)

        if time_key and time_key in prayers:
            schedule_prayer(app, user_id, chat_id, prayer_name, prayers[time_key], offset)

# === Scheduler ishga tushishi ===
async def start_scheduler(app):
    if not scheduler.running:
        scheduler.start()
        print("📆 Scheduler ishga tushdi.")
