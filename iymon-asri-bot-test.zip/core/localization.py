import json

def get_lang(user_id):
    try:
        with open("data/user_data.json", "r", encoding="utf-8") as f:
            users = json.load(f)
        return users.get(str(user_id), {}).get("lang", "uz")
    except:
        return "uz"

texts = {
    "uz": {
        "choose_bayram": "⛱ Qaysi bayram haqida ma’lumot olmoqchisiz?",
        "hadis_oyat_intro": "📖 Bu yerda siz tasodifiy hadis yoki oyat olishingiz mumkin:",
        "hadis_oyat_hadis": "Hadis",
        "hadis_oyat_oyat": "Oyat",
        "back": "Ortga",
        "start": "🤖 Assalomu alaykum!\n\nBu bot sizga quyidagi xizmatlarni taqdim etadi:",
        "menu": [
            "🍌 Namoz vaqti", "🌤 Ob-havo", "🎉 Bayramlar", "🔋 Hadislar / Oyatlar",
            "📖 Kun oyati", "🖑 Namozga eslatma", "🌐 Til sozlamasi", "🕓 Ro‘za vaqtlari", "❓ Yordam"
        ],
        "choose_option": "Iltimos, kerakli bo‘limni tanlang 👇",
        "choose_lang": "🌐 Tilni tanlang:",
    },
    "ru": {
        "choose_bayram": "⛱ Какой праздник вас интересует?",
        "hadis_oyat_intro": "📖 Здесь вы можете получить случайный хадис или аят:",
        "hadis_oyat_hadis": "Хадис",
        "hadis_oyat_oyat": "Аят",
        "back": "Назад",
        "start": "🤖 Ассаламу алейкум!\n\nЭтот бот предлагает следующие функции:",
        "menu": [
            "🍌 Время намаза", "🌤 Погода", "🎉 Праздники", "🔋 Хадисы / Аяты",
            "📖 Аят дня", "🖑 Напоминание на намаз", "🌐 Настройки языка", "🕓 Время поста", "❓ Помощь"
        ],
        "choose_option": "Пожалуйста, выберите раздел 👇",
        "choose_lang": "🌐 Выберите язык:",

    }
}
