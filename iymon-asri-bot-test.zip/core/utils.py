import asyncio
from telegram.error import TimedOut, RetryAfter


#safe-send yordamchi funksiyasi
async def safe_send(bot, chat_id: int, **kwargs):
    """
    Bot so‘rovlarini vaqtinchalik muammolarga qarshi retry mexanizmi bilan o‘rab oladi.
    Max 3 urinish, har safar RetryAfter dan olinadigan vaqt kutiladi.
    """
    for attempt in range(1, 4):
        try:
            return await bot.send_message(chat_id=chat_id, **kwargs)
        except RetryAfter as e:
            wait = e.retry_after or 5
            print(f"[SAFE_SEND] RetryAfter: {wait}s, urinish #{attempt}")
            await asyncio.sleep(wait)
        except TimedOut:
            backoff = 5 * attempt
            print(f"[SAFE_SEND] TimedOut, {backoff}s kutib qayta urinayapman…")
            await asyncio.sleep(backoff)
        except Exception as e:
            print(f"[SAFE_SEND] Boshqa xato: {e}")
            break
    print("[SAFE_SEND] Xabar jo‘natilmadi.")
