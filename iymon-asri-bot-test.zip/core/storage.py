import json
import os

DATA_FILE = "data/user_data.json"

def load_user_data():
    if not os.path.exists(DATA_FILE):
        return {}
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_user_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def get_user(user_id):
    data = load_user_data()
    return data.get(str(user_id), {})

def update_user(user_id, key, value):
    data = load_user_data()
    uid = str(user_id)
    if uid not in data:
        data[uid] = {}
    data[uid][key] = value
    save_user_data(data)

def get_lang(user_id):
    return get_user(user_id).get("lang", "uz")
